<?php
$host = "localhost";
$user = "u540720437_manuel";
$pass = "Ju@n290503";
$db   = "u540720437_personal";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

// Función auxiliar para registrar en la bitácora
function registrarBitacora($pdo, $usuario_id, $accion) {
    $stmt = $pdo->prepare("INSERT INTO bitacora (usuario_id, accion) VALUES (?, ?)");
    $stmt->execute([$usuario_id, $accion]);
}
?>