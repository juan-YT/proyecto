<?php
require 'conexion.php';
session_start();

// Simulación de sesión de seguridad (Descomentar cuando integres el login)
// if(!isset($_SESSION['usuario_id'])) { header("Location: login.php"); exit; }
$usuario_sesion_id = isset($_SESSION['usuario_id']) ? $_SESSION['usuario_id'] : null; 

$msg = "";

// --- LÓGICA 1: REGISTRO DE EMPLEADO CON FOTO ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registrar_empleado'])) {
    $nombre = trim($_POST['nombre']);
    $puesto = trim($_POST['puesto']);
    $sueldo = floatval($_POST['sueldo']);
    $nombre_foto = "default.png";

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $permitidos = ['jpg', 'jpeg', 'png', 'webp'];
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        
        if (in_array(strtolower($ext), $permitidos)) {
            // Renombrar archivo para evitar duplicados
            $nombre_foto = time() . "_" . basename($_FILES['foto']['name']);
            $ruta_destino = "uploads/" . $nombre_foto;
            
            // Crear carpeta si no existe
            if (!is_dir('uploads')) { mkdir('uploads', 0777, true); }
            move_uploaded_file($_FILES['foto']['tmp_temp_name'] ?? $_FILES['foto']['tmp_name'], $ruta_destino);
        }
    }

    $stmt = $pdo->prepare("INSERT INTO empleados (nombre, puesto, sueldo_base, foto) VALUES (?, ?, ?, ?)");
    $stmt->execute([$nombre, $puesto, $sueldo, $nombre_foto]);
    
    registrarBitacora($pdo, $usuario_sesion_id, "Registró al empleado: $nombre");
    $msg = "Empleado registrado con éxito.";
}

// --- CONSULTAS ---
$empleados = $pdo->query("SELECT * FROM empleados ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
$nominas = $pdo->query("SELECT n.*, e.nombre FROM nomina n JOIN empleados e ON n.empleado_id = e.id")->fetchAll(PDO::FETCH_ASSOC);
$bitacora = $pdo->query("SELECT b.*, u.nombre AS usuario FROM bitacora b LEFT JOIN usuarios u ON b.usuario_id = u.id ORDER BY b.fecha DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
$productos = $pdo->query("SELECT * FROM productos_servicios")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Administración de Personal</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background: #f8f9fa; display: flex; }
        .sidebar { width: 250px; background: #2c3e50; color: white; min-height: 100vh; padding: 20px; box-sizing: border-box; }
        .sidebar h2 { font-size: 18px; margin-bottom: 30px; border-bottom: 1px solid #4f5d73; padding-bottom: 10px; }
        .sidebar a { color: #b8c7ce; display: block; padding: 10px 5px; text-decoration: none; border-radius: 4px; }
        .sidebar a:hover { background: #34495e; color: white; }
        .main-content { flex: 1; padding: 30px; box-sizing: border-box; }
        .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 30px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        table, th, td { border: 1px solid #dee2e6; }
        th, td { padding: 12px; text-align: left; }
        th { background-color: #f1f3f5; }
        .img-empleado { width: 50px; height: 50px; border-radius: 50%; object-fit: cover; }
        .grid-forms { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group input, .form-group select { width: 100%; padding: 8px; margin: 5px 0 15px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box;}
        .btn { background: #007bff; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
        .btn:hover { background: #0056b3; }
    </style>
</head>
<body>

<div class="sidebar">
    <h2>Módulos Sistema</h2>
    <a href="#registro">Registrar Personal</a>
    <a href="#consultar">Consultar Personal</a>
    <a href="#nomina">Nóminas</a>
    <a href="#productos">Productos / Servicios</a>
    <a href="#bitacora">Bitácora General</a>
</div>

<div class="main-content">
    <h1>Panel de Administración Personal</h1>
    <?php if($msg): ?> <p style="color: green; font-weight: bold;"><?= $msg ?></p> <?php endif; ?>

    <!-- SECCIÓN 1: REGISTRO -->
    <div id="registro" class="card">
        <h2>Registro de Nuevo Personal (con Foto)</h2>
        <form action="" method="POST" enctype="multipart/form-data" class="grid-forms">
            <div class="form-group">
                <label>Nombre del Empleado:</label>
                <input type="text" name="nombre" required>
                
                <label>Puesto / Cargo:</label>
                <input type="text" name="puesto" required>
            </div>
            <div class="form-group">
                <label>Sueldo Base ($):</label>
                <input type="number" step="0.01" name="sueldo" required>
                
                <label>Fotografía de Perfil:</label>
                <input type="file" name="foto" accept="image/*">
            </div>
            <div style="grid-column: span 2;">
                <button type="submit" name="registrar_empleado" class="btn">Guardar Empleado</button>
            </div>
        </form>
    </div>

    <!-- SECCIÓN 2: CONSULTA DE PERSONAL -->
    <div id="consultar" class="card">
        <h2>Listado y Consulta de Personal</h2>
        <table>
            <thead>
                <tr>
                    <th>Foto</th>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Puesto</th>
                    <th>Sueldo Base</th>
                    <th>Fecha Alta</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($empleados as $emp): ?>
                <tr>
                    <td><img src="uploads/<?= htmlspecialchars($emp['foto']) ?>" class="img-empleado" alt="Foto"></td>
                    <td><?= $emp['id'] ?></td>
                    <td><?= htmlspecialchars($emp['nombre']) ?></td>
                    <td><?= htmlspecialchars($emp['puesto']) ?></td>
                    <td>$<?= number_format($emp['sueldo_base'], 2) ?></td>
                    <td><?= $emp['creado_en'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- SECCIÓN 3: CONSULTA DE NÓMINA -->
    <div id="nomina" class="card">
        <h2>Historial y Consulta de Nóminas</h2>
        <table>
            <thead>
                <tr>
                    <th>Empleado</th>
                    <th>Fecha de Pago</th>
                    <th>Deducciones</th>
                    <th>Bonos</th>
                    <th>Neto Pagado</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($nominas as $nom): ?>
                <tr>
                    <td><?= htmlspecialchars($nom['nombre']) ?></td>
                    <td><?= $nom['fecha_pago'] ?></td>
                    <td>$<?= number_format($nom['deducciones'], 2) ?></td>
                    <td>$<?= number_format($nom['bonos'], 2) ?></td>
                    <td><strong>$<?= number_format($nom['neto_pagar'], 2) ?></strong></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- SECCIÓN 4: LISTADO DE PRODUCTOS O SERVICIOS -->
    <div id="productos" class="card">
        <h2>Catálogo de Productos o Servicios</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Descripción / Nombre</th>
                    <th>Tipo</th>
                    <th>Precio Comercial</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($productos as $prod): ?>
                <tr>
                    <td><?= $prod['id'] ?></td>
                    <td><?= htmlspecialchars($prod['nombre']) ?></td>
                    <td><?= $prod['tipo'] ?></td>
                    <td>$<?= number_format($prod['precio'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- SECCIÓN 5: BITÁCORA -->
    <div id="bitacora" class="card">
        <h2>Bitácora de Auditoría (Últimos 10 movimientos)</h2>
        <table style="font-size: 14px;">
            <thead>
                <tr>
                    <th>Fecha / Hora</th>
                    <th>Usuario Ejecutor</th>
                    <th>Acción Realizada</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($bitacora as $bit): ?>
                <tr>
                    <td><?= $bit['fecha'] ?></td>
                    <td><?= $bit['usuario'] ?? 'Sistema/Invitado' ?></td>
                    <td><?= htmlspecialchars($bit['accion']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>