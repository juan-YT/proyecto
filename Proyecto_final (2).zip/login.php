<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'conexion.php';
session_start();

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = trim($_POST['correo']);
    $password = trim($_POST['password']);

    try {
        // Buscamos al usuario por su correo
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE correo = ?");
        $stmt->execute([$correo]);
        $usuario = $stmt->fetch();

        // Validamos si existe, si la contraseña es correcta y si ya verificó su correo
        if ($usuario && password_verify($password, $usuario['password'])) {
            if ($usuario['activo'] == 1) {
                // Creamos la sesión segura
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nombre'] = $usuario['nombre'];

                // Registramos la acción en la bitácora
                registrarBitacora($pdo, $usuario['id'], "Inicio de sesión exitoso.");

                // Redireccionamos al panel de administración
                header("Location: panel.php");
                exit;
            } else {
                $mensaje = "Tu cuenta aún no ha sido activada. Por favor, verifica tu correo electrónico.";
            }
        } else {
            $mensaje = "Correo electrónico o contraseña incorrectos.";
        }
    } catch (PDOException $e) {
        $mensaje = "Hubo un error al intentar iniciar sesión.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <style>
        body { font-family: Arial, sans-serif; background: #121212; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; color: #fff; }
        .form-container { background: #1e1e1e; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); width: 100%; max-width: 400px; }
        h2 { margin-top: 0; color: #fff; text-align: center; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #333; background: #2a2a2a; color: #fff; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; margin-top: 10px; }
        button:hover { background: #218838; }
        .alert { padding: 10px; background: #2a2a2a; border-left: 4px solid #dc3545; margin-bottom: 15px; border-radius: 4px; color: #ddd; font-size: 14px; }
        .register-link { text-align: center; margin-top: 15px; font-size: 14px; }
        .register-link a { color: #28a745; text-decoration: none; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Iniciar Sesión</h2>
    <?php if(!empty($mensaje)): ?>
        <div class="alert"><?php echo $mensaje; ?></div>
    <?php endif; ?>
    
    <form action="" method="POST">
        <input type="email" name="correo" placeholder="Correo electrónico" required>
        <input type="password" name="password" placeholder="Contraseña" required>
        <button type="submit">Ingresar al Sistema</button>
    </form>
    
    <div class="register-link">
        ¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a>
    </div>
</div>

</body>
</html>