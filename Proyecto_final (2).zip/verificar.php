<?php
require 'conexion.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Buscar si el token existe
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE token = ? AND activo = 0");
    $stmt->execute([$token]);
    $usuario = $stmt->fetch();

    if ($usuario) {
        // Activar usuario y limpiar el token
        $update = $pdo->prepare("UPDATE usuarios SET activo = 1, token = NULL WHERE id = ?");
        $update->execute([$usuario['id']]);

        registrarBitacora($pdo, $usuario['id'], "Cuenta activada vía correo electrónico.");
        echo "<h3>¡Tu cuenta ha sido activada con éxito! Ya puedes <a href='login.php'>iniciar sesión</a>.</h3>";
    } else {
        echo "<h3>El enlace es inválido o la cuenta ya ha sido activada.</h3>";
    }
} else {
    echo "<h3>Token no proporcionado.</h3>";
}
?>