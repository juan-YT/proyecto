<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'conexion.php';

// Importar clases de PHPMailer al espacio de nombres global
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Cargar los archivos de la librería según tu nueva estructura de carpetas
require 'libs/PHPMailer/src/Exception.php';
require 'libs/PHPMailer/src/PHPMailer.php';
require 'libs/PHPMailer/src/SMTP.php';

$mensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST['nombre']);
    $correo = trim($_POST['correo']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $token = bin2hex(random_bytes(16)); // Genera un token único

    try {
        // 1. Guardar el usuario inactivo en la base de datos (activo = 0)
        $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, correo, password, token, activo) VALUES (?, ?, ?, ?, 0)");
        $stmt->execute([$nombre, $correo, $password, $token]);

        // 2. Construir el enlace de verificación dinámico automático para la carpeta Proyecto_final
        $protocolo = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https" : "http";
        $ruta_actual = dirname($_SERVER['REQUEST_URI']);
        $enlace_verificacion = $protocolo . "://" . $_SERVER['HTTP_HOST'] . "/Proyecto_final/verificar.php?token=" . $token;

        // 3. Configurar e iniciar PHPMailer mediante SMTP seguro
        $mail = new PHPMailer(true);

        // Ajustes del servidor de Hostinger
        $mail->isSMTP();
        $mail->Host       = 'smtp.hostinger.com';             // Servidor SMTP oficial de Hostinger
        $mail->SMTPAuth   = true;                             // Habilitar autenticación SMTP
        $mail->Username   = 'juan@practica.juan-manu.com';         // ◄--- CAMBIA AQUÍ: Tu correo de Hostinger
        $mail->Password   = 'M@nuel290503';          // ◄--- CAMBIA AQUÍ: Tu contraseña del correo
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;      // Encriptación SSL segura
        $mail->Port       = 465;                              // Puerto seguro SMTP de Hostinger

        // Configurar Remitente y Destinatario
        $mail->setFrom('juan@practica.juan-manu.com', 'Sistema Personal'); 
        $mail->addAddress($correo, $nombre);                  // El correo de Gmail que se escribe en el formulario

        // Diseño del Correo en HTML
        $mail->isHTML(true);
        $mail->CharSet = 'UTF-8';
        $mail->Subject = 'Verifica tu cuenta - Sistema de Personal';
        
        $mail->Body = "
        <html>
        <body style='font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; color: #333;'>
            <div style='background-color: #fff; max-width: 500px; margin: 0 auto; padding: 30px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);'>
                <h2 style='color: #28a745; text-align: center;'>¡Bienvenido, " . htmlspecialchars($nombre) . "!</h2>
                <p style='font-size: 16px; line-height: 1.5;'>Gracias por registrarte. Para completar tu alta y activar tu cuenta, por favor presiona el siguiente botón:</p>
                <p style='text-align: center; margin: 30px 0;'>
                    <a href='" . $enlace_verificacion . "' style='background-color: #28a745; color: white; padding: 12px 25px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;'>Activar mi Cuenta de Correo</a>
                </p>
                <p style='color: #999; font-size: 12px; border-top: 1px solid #eee; padding-top: 15px;'>Si el botón no funciona, copia y pega este enlace en tu navegador:<br>" . $enlace_verificacion . "</p>
            </div>
        </body>
        </html>
        ";

        // Enviar el email real
        $mail->send();
        
        $mensaje = "¡Usuario registrado con éxito! Te hemos enviado un correo de activación. Por favor, revisa tu bandeja de entrada o SPAM.";
        registrarBitacora($pdo, null, "Nuevo usuario registrado (esperando verificación): $correo");

    } catch (Exception $e) {
        $mensaje = "El usuario se guardó, pero hubo un error al enviar el correo electrónico: {$mail->ErrorInfo}";
    } catch (PDOException $e) {
        $mensaje = "Error: El correo electrónico ya se encuentra registrado o hubo un problema con la base de datos.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro de Usuario</title>
    <style>
        body { font-family: Arial, sans-serif; background: #121212; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; color: #fff; }
        .form-container { background: #1e1e1e; padding: 30px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); width: 100%; max-width: 400px; }
        h2 { margin-top: 0; color: #fff; text-align: center; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #333; background: #2a2a2a; color: #fff; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #28a745; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; margin-top: 10px; }
        button:hover { background: #218838; }
        .alert { padding: 10px; background: #2a2a2a; border-left: 4px solid #007bff; margin-bottom: 15px; border-radius: 4px; color: #ddd; font-size: 14px; }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Registro de Usuario</h2>
    <?php if(!empty($mensaje)): ?>
        <div class="alert"><?php echo $mensaje; ?></div>
    <?php endif; ?>
    
    <form id="registroForm" action="" method="POST">
        <input type="text" name="nombre" placeholder="Nombre completo" required>
        <input type="email" name="correo" placeholder="Correo electrónico" required>
        <input type="password" id="password" name="password" placeholder="Contraseña (mínimo 6 caracteres)" required>
        <button type="submit">Registrarse</button>
    </form>
</div>

<script>
document.getElementById('registroForm').addEventListener('submit', function(e) {
    const pass = document.getElementById('password').value;
    if(pass.length < 6) {
        alert('La contraseña debe tener al menos 6 caracteres.');
        e.preventDefault();
    }
});
</script>

</body>
</html>